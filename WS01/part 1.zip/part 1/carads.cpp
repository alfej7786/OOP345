#include <cstring>
#include <iomanip>
#include "carads.h"

using namespace std;
namespace sdds {
    static int counter = 0;
    Cars::Cars(): m_price(0), m_discount(false) {

    }

    void Cars::read(std::istream& is){
        char discount = false;
        char status = false;
        if (is) {
            if (status == 'N') {
                m_status = true; // New Car
            }
            else if (status == 'U') {
                m_status = false; // Old Car
            }
            is.ignore(); //
            is.getline(m_brand, 10, ',');
            is.getline(m_model, 15, ',');
            is >> m_made_year;
            is. ignore(); //
            is >> m_price;
            is.ignore(); //
            if(discount == 'Y')
            {
                m_discount = true;
            }
            else if(discount == 'N')
            {
                m_discount = false;
            }
            is.ignore(); //
        }
        else {
            exit;
        }
    }

    void Cars::display(bool reset){ 
        bool reset = true;
        cout.width(2);
        cout.setf(std::ios::left);
        cout << ++counter;
        cout << ". ";
        if (reset)
        {
            cout.width(10);
            cout.setf(std::ios::left);
            cout << m_brand;
            cout << '|';

            cout.width(15);
            cout.setf(std::ios::left);
            cout << m_model;
            cout << '|';

            cout.width(4);
            cout << m_made_year;
            cout << '|';

            cout.width(12);
            cout.precision(2);
            cout.setf(std::ios::left);
            cout << m_price + (m_price + g_taxrate);
            cout << '|';

            if(m_discount) {
                cout.setf(ios::right);
                cout.precision(2);
                cout.setf(std::ios::right);
                cout.width(12);
                cout << (m_price +(m_price * g_taxrate)) - g_discount;
                cout.unsetf(ios::right);
                cout.unsetf(ios::fixed);
            }
            cout << endl;
        }
        else {
            cout << ++counter;
            cout << "No Car";
            }
    }

    char Cars::getStatus() {
        return m_status;
    }
}