
#include <iostream>
#include "Book.h"
using namespace std;

namespace sdds
{
    Book::Book()
    {
        ;
    }

    string &Book::trim(string &str) {
        bool trimmed = false;

        while (!trimmed)
        {
            trimmed = true;
            if (str.find(' ') == 0)
            {
                trimmed = false;
                str.erase(str.begin());
            }
            if (str.substr(str.size() - 1, 1).find(' ') != string::npos)
            {
                str.erase(str.end() - 1);
                trimmed = false;
            }
        }
        return str;
    }


    Book::Book(const string &strBook) {
        string token{};
        size_t left{};
        size_t right{strBook.find(",")};
        m_author = strBook.substr(left, right);
        m_author = trim(m_author);
        left = right;
        right = strBook.find(",", left + 1);
        m_title = strBook.substr(left + 1, right - left - 1);
        m_title = trim(m_title);
        left = right;
        right = strBook.find(",", left + 1);
        m_country = strBook.substr(left + 1, right - left - 1);
        m_country = trim(m_country);
        left = right;
        right = strBook.find(",", left + 1);
        token = strBook.substr(left + 1, right - left - 1);
        m_price = stod(token);
        left = right;
        right = strBook.find(",", left + 1);
        token = strBook.substr(left + 1, right - left - 1);
        m_year = stoi(token);
        left = right;
        right = strBook.find('\n', left + 1);
        m_description = strBook.substr(left + 1, right - left - 1);
        m_description = trim(m_description);
    }

    const string &Book::title() const { 
        return m_title; 
    }

    
    const string &Book::country() const { 
        return m_country; 
    }

    
    const size_t &Book::year() const { 
        return m_year; 
    }

    
    double &Book::price() { 
        return m_price; 
    }

    
    ostream &operator<<(ostream &os, const Book &book) {
        os.width(20);
        os << book.m_author << " | ";
        os.width(22);
        os << book.m_title << " | ";
        os.width(5);
        os << book.m_country << " | ";
        os.width(4);
        os << book.m_year << " | ";
        os.width(6);
        os.precision(2);
        os << fixed << book.m_price << " | " << book.m_description << endl;

        return os;
    }

} // namespace sdds